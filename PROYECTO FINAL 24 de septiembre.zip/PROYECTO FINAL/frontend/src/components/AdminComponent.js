import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './styled-components/Profile.css';

const AdminComponent = () => {
  const [selectedOption, setSelectedOption] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('employee');
  const [message, setMessage] = useState('');
  const [users, setUsers] = useState([]);
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false); // Para controlar si estamos editando un usuario
  const [editUserId, setEditUserId] = useState(null); // Para almacenar el ID del usuario que se está editando
  const navigate = useNavigate();

  useEffect(() => {
    if (selectedOption === 'Usuarios') {
      fetchUsers();
    }
  }, [selectedOption]);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/auth/users');
      const result = await response.json();
      if (response.ok) {
        setUsers(result);
      } else {
        setMessage('Error al obtener usuarios');
      }
    } catch (error) {
      console.error('Error al obtener usuarios:', error);
      setMessage('Error en el servidor');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    navigate('/');
  };

  const handleCreateUser = async (event) => {
    event.preventDefault();
    if (isEditing) {
      handleUpdateUser(editUserId); // Si estamos editando, actualiza el usuario
    } else {
      // Si no estamos editando, crea un nuevo usuario
      try {
        const response = await fetch('http://localhost:3000/api/auth/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ username, password, role }),
        });

        const result = await response.json();
        if (response.ok) {
          setMessage('Usuario creado exitosamente');
          setUsername('');
          setPassword('');
          setRole('employee');
          setShowAddUserForm(false); 
          fetchUsers(); 
        } else {
          setMessage(result.error || 'Error al crear el usuario');
        }
      } catch (error) {
        console.error('Error al crear usuario:', error);
        setMessage('Error en el servidor');
      }
    }
  };

  const handleDeleteUser = async (userId) => {
    const confirmDelete = window.confirm('¿Estás seguro de que deseas eliminar este usuario?');
    if (!confirmDelete) return;

    try {
      const response = await fetch(`http://localhost:3000/api/auth/users/${userId}`, {
        method: 'DELETE',
      });

      const result = await response.json();
      if (response.ok) {
        setMessage('Usuario eliminado correctamente');
        fetchUsers(); // Actualiza la lista de usuarios
      } else {
        setMessage(result.error || 'Error al eliminar el usuario');
      }
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
      setMessage('Error en el servidor');
    }
  };

  const handleEditUser = (user) => {
    setIsEditing(true); // Activa el modo de edición
    setEditUserId(user.id); // Establece el ID del usuario a editar
    setUsername(user.username); // Pre-rellena el nombre de usuario
    setRole(user.role); // Pre-rellena el rol
    setShowAddUserForm(true); // Muestra el formulario para editar
  };

  const handleUpdateUser = async (userId) => {
    try {
      const response = await fetch(`http://localhost:3000/api/auth/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password, role }),
      });

      const result = await response.json();
      if (response.ok) {
        setMessage('Usuario actualizado correctamente');
        setUsername('');
        setPassword('');
        setRole('employee');
        setShowAddUserForm(false); 
        setIsEditing(false); 
        fetchUsers(); 
      } else {
        setMessage(result.error || 'Error al actualizar el usuario');
      }
    } catch (error) {
      console.error('Error al actualizar usuario:', error);
      setMessage('Error en el servidor');
    }
  };

  return (
    <div className="admin-dashboard">
      {/* Barra de navegación lateral */}
      <nav className="sidebar">
        <div className="user-info">
          <p>Bienvenido, Admin</p>
        </div>
        <ul>
          <li onClick={() => setSelectedOption('Inicio')}>Inicio</li>
          <li onClick={() => setSelectedOption('Usuarios')}>Usuarios</li>
          <li onClick={() => setSelectedOption('Asistencias')}>Asistencias</li>
          <li onClick={() => setSelectedOption('Configuración')}>Configuración</li>
        </ul>
        <button className="logout-button" onClick={handleLogout}>Cerrar sesión</button>
      </nav>

      {/* Contenido principal */}
      <div className="main-content">
        {/* Título en la parte superior derecha */}
        <header>
          <h1>Panel del Administrador</h1>
        </header>

        {/* Vista central */}
        <section className="content">
          {selectedOption === '' ? (
            <div>
              <h2>Trabajando en modo Administrador</h2>
              <p>No tienes ninguna opción seleccionada.</p>
            </div>
          ) : selectedOption === 'Usuarios' ? (
            <div>
              <h2>Usuarios</h2>
              <div className="user-list-container">
                {users.length > 0 ? (
                  <table>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Nombre de Usuario</th>
                        <th>Rol</th>
                        <th>Acciones</th> {/* Columna para las acciones */}
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td>{user.id}</td>
                          <td>{user.username}</td>
                          <td>{user.role}</td>
                          <td>
                            <button
                              className="edit-button"
                              onClick={() => handleEditUser(user)}
                            >
                              Editar
                            </button>
                            <button
                              className="delete-button"
                              onClick={() => handleDeleteUser(user.id)}
                            >
                              Eliminar
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <p>No hay usuarios.</p>
                )}
              </div>

              {/* Botón para mostrar/ocultar el formulario de agregar usuario */}
              <button className="add-user-button" onClick={() => {
                setIsEditing(false); // Desactiva el modo de edición si estamos agregando un nuevo usuario
                setShowAddUserForm(!showAddUserForm);
              }}>
                {showAddUserForm ? 'Cancelar' : 'Agregar Usuario'}
              </button>

              {/* Formulario para crear o editar un usuario */}
              {showAddUserForm && (
                <div className="add-user-container">
                  <h3>{isEditing ? 'Editar Usuario' : 'Agregar Usuario'}</h3>
                  <form onSubmit={handleCreateUser}>
                    <div>
                      <label>Nombre de usuario:</label>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <label>Contraseña:</label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required={!isEditing} // No requiere contraseña si estamos editando
                      />
                    </div>
                    <div>
                      <label>Rol:</label>
                      <select value={role} onChange={(e) => setRole(e.target.value)} required>
                        <option value="admin">Administrador</option>
                        <option value="employee">Empleado</option>
                      </select>
                    </div>
                    <button type="submit">
                      {isEditing ? 'Actualizar Usuario' : 'Crear Usuario'}
                    </button>
                  </form>
                  {message && <p>{message}</p>}
                </div>
              )}
            </div>
          ) : (
            <div>
              <h2>{selectedOption}</h2>
              <p>Esta es la vista para {selectedOption}.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default AdminComponent;